package net.uglobal.swiftvalidator.xml.beans;

public class MT535 extends MTMessage {

}
