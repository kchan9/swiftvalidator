package net.uglobal.swiftvalidator.xml.beans;

public class MT537 extends MTMessage {

}
