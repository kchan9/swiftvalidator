package net.uglobal.swiftvalidator.xml.beans;

public class MT504 extends MTMessage {

}
