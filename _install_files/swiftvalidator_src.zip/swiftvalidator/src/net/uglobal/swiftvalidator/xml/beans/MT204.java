package net.uglobal.swiftvalidator.xml.beans;

public class MT204 extends MTMessage {

}
