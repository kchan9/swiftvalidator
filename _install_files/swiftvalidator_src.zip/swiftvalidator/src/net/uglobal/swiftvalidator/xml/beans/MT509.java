package net.uglobal.swiftvalidator.xml.beans;

public class MT509 extends MTMessage {

}
