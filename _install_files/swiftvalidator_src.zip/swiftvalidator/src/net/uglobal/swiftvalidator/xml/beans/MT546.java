package net.uglobal.swiftvalidator.xml.beans;

public class MT546 extends MTMessage {

}
