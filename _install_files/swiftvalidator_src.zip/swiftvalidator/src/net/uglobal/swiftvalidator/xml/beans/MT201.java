package net.uglobal.swiftvalidator.xml.beans;

public class MT201 extends MTMessage {

}
