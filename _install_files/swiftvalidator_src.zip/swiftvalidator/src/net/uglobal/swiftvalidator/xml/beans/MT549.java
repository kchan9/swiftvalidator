package net.uglobal.swiftvalidator.xml.beans;

public class MT549 extends MTMessage {

}
