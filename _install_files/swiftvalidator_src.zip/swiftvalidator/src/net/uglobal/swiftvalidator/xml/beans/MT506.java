package net.uglobal.swiftvalidator.xml.beans;

public class MT506 extends MTMessage {

}
