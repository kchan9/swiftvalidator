package net.uglobal.swiftvalidator.xml.beans;

public class MT307 extends MTMessage {

}
