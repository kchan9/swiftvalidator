package net.uglobal.swiftvalidator.xml.beans;

public class MT502 extends MTMessage {

}
