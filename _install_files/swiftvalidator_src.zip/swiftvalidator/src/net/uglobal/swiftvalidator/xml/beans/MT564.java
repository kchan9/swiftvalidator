
package net.uglobal.swiftvalidator.xml.beans;

import java.util.List;
import net.uglobal.swiftvalidator.swift.field.Field;


/**
 * AUTO GENERATED - DO NOT HAND MODIFY
 * Generated on Sun Oct 21 08:27:13 EDT 2012
 * 
 */
public class MT564
    extends MTMessage
{


    public MT564() {
        super();
    }

    public List<Field> getField16R() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field16R.class);
    }

    public List<Field> getField20C() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field20C.class);
    }

    public List<Field> getField23G() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field23G.class);
    }

    public List<Field> getField22F() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field22F.class);
    }

    public List<Field> getField98A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field98A.class);
    }

    public List<Field> getField98C() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field98C.class);
    }

    public List<Field> getField25D() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field25D.class);
    }

    public List<Field> getField13A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field13A.class);
    }

    public List<Field> getField13B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field13B.class);
    }

    public List<Field> getField16S() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field16S.class);
    }

    public List<Field> getField35B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field35B.class);
    }

    public List<Field> getField94B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field94B.class);
    }

    public List<Field> getField12A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field12A.class);
    }

    public List<Field> getField12B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field12B.class);
    }

    public List<Field> getField12C() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field12C.class);
    }

    public List<Field> getField11A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field11A.class);
    }

    public List<Field> getField92A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92A.class);
    }

    public List<Field> getField92K() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92K.class);
    }

    public List<Field> getField36B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field36B.class);
    }

    public List<Field> getField95P() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field95P.class);
    }

    public List<Field> getField95R() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field95R.class);
    }

    public List<Field> getField97A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field97A.class);
    }

    public List<Field> getField97C() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field97C.class);
    }

    public List<Field> getField94C() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field94C.class);
    }

    public List<Field> getField94F() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field94F.class);
    }

    public List<Field> getField93B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field93B.class);
    }

    public List<Field> getField93C() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field93C.class);
    }

    public List<Field> getField36E() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field36E.class);
    }

    public List<Field> getField92D() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92D.class);
    }

    public List<Field> getField90B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field90B.class);
    }

    public List<Field> getField98B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field98B.class);
    }

    public List<Field> getField69A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field69A.class);
    }

    public List<Field> getField69B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field69B.class);
    }

    public List<Field> getField69C() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field69C.class);
    }

    public List<Field> getField69D() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field69D.class);
    }

    public List<Field> getField69E() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field69E.class);
    }

    public List<Field> getField69F() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field69F.class);
    }

    public List<Field> getField98E() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field98E.class);
    }

    public List<Field> getField69J() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field69J.class);
    }

    public List<Field> getField99A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field99A.class);
    }

    public List<Field> getField92F() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92F.class);
    }

    public List<Field> getField90A() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field90A.class);
    }

    public List<Field> getField90E() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field90E.class);
    }

    public List<Field> getField36C() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field36C.class);
    }

    public List<Field> getField17B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field17B.class);
    }

    public List<Field> getField94G() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field94G.class);
    }

    public List<Field> getField70E() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field70E.class);
    }

    public List<Field> getField70G() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field70G.class);
    }

    public List<Field> getField98F() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field98F.class);
    }

    public List<Field> getField92J() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92J.class);
    }

    public List<Field> getField90F() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field90F.class);
    }

    public List<Field> getField90J() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field90J.class);
    }

    public List<Field> getField22H() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field22H.class);
    }

    public List<Field> getField92L() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92L.class);
    }

    public List<Field> getField92M() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92M.class);
    }

    public List<Field> getField92N() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92N.class);
    }

    public List<Field> getField97E() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field97E.class);
    }

    public List<Field> getField19B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field19B.class);
    }

    public List<Field> getField92B() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field92B.class);
    }

    public List<Field> getField90K() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field90K.class);
    }

    public List<Field> getField95Q() {
        return getFieldsByFieldClass().get(net.uglobal.swiftvalidator.swift.field.Field95Q.class);
    }

    public List<Field> getField16R(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField16R(), sequenceShortName);
    }

    public List<Field> getField20C(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField20C(), sequenceShortName);
    }

    public List<Field> getField23G(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField23G(), sequenceShortName);
    }

    public List<Field> getField22F(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField22F(), sequenceShortName);
    }

    public List<Field> getField98A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField98A(), sequenceShortName);
    }

    public List<Field> getField98C(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField98C(), sequenceShortName);
    }

    public List<Field> getField25D(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField25D(), sequenceShortName);
    }

    public List<Field> getField13A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField13A(), sequenceShortName);
    }

    public List<Field> getField13B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField13B(), sequenceShortName);
    }

    public List<Field> getField16S(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField16S(), sequenceShortName);
    }

    public List<Field> getField35B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField35B(), sequenceShortName);
    }

    public List<Field> getField94B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField94B(), sequenceShortName);
    }

    public List<Field> getField12A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField12A(), sequenceShortName);
    }

    public List<Field> getField12B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField12B(), sequenceShortName);
    }

    public List<Field> getField12C(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField12C(), sequenceShortName);
    }

    public List<Field> getField11A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField11A(), sequenceShortName);
    }

    public List<Field> getField92A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92A(), sequenceShortName);
    }

    public List<Field> getField92K(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92K(), sequenceShortName);
    }

    public List<Field> getField36B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField36B(), sequenceShortName);
    }

    public List<Field> getField95P(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField95P(), sequenceShortName);
    }

    public List<Field> getField95R(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField95R(), sequenceShortName);
    }

    public List<Field> getField97A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField97A(), sequenceShortName);
    }

    public List<Field> getField97C(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField97C(), sequenceShortName);
    }

    public List<Field> getField94C(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField94C(), sequenceShortName);
    }

    public List<Field> getField94F(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField94F(), sequenceShortName);
    }

    public List<Field> getField93B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField93B(), sequenceShortName);
    }

    public List<Field> getField93C(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField93C(), sequenceShortName);
    }

    public List<Field> getField36E(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField36E(), sequenceShortName);
    }

    public List<Field> getField92D(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92D(), sequenceShortName);
    }

    public List<Field> getField90B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField90B(), sequenceShortName);
    }

    public List<Field> getField98B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField98B(), sequenceShortName);
    }

    public List<Field> getField69A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField69A(), sequenceShortName);
    }

    public List<Field> getField69B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField69B(), sequenceShortName);
    }

    public List<Field> getField69C(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField69C(), sequenceShortName);
    }

    public List<Field> getField69D(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField69D(), sequenceShortName);
    }

    public List<Field> getField69E(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField69E(), sequenceShortName);
    }

    public List<Field> getField69F(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField69F(), sequenceShortName);
    }

    public List<Field> getField98E(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField98E(), sequenceShortName);
    }

    public List<Field> getField69J(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField69J(), sequenceShortName);
    }

    public List<Field> getField99A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField99A(), sequenceShortName);
    }

    public List<Field> getField92F(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92F(), sequenceShortName);
    }

    public List<Field> getField90A(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField90A(), sequenceShortName);
    }

    public List<Field> getField90E(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField90E(), sequenceShortName);
    }

    public List<Field> getField36C(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField36C(), sequenceShortName);
    }

    public List<Field> getField17B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField17B(), sequenceShortName);
    }

    public List<Field> getField94G(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField94G(), sequenceShortName);
    }

    public List<Field> getField70E(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField70E(), sequenceShortName);
    }

    public List<Field> getField70G(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField70G(), sequenceShortName);
    }

    public List<Field> getField98F(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField98F(), sequenceShortName);
    }

    public List<Field> getField92J(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92J(), sequenceShortName);
    }

    public List<Field> getField90F(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField90F(), sequenceShortName);
    }

    public List<Field> getField90J(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField90J(), sequenceShortName);
    }

    public List<Field> getField22H(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField22H(), sequenceShortName);
    }

    public List<Field> getField92L(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92L(), sequenceShortName);
    }

    public List<Field> getField92M(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92M(), sequenceShortName);
    }

    public List<Field> getField92N(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92N(), sequenceShortName);
    }

    public List<Field> getField97E(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField97E(), sequenceShortName);
    }

    public List<Field> getField19B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField19B(), sequenceShortName);
    }

    public List<Field> getField92B(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField92B(), sequenceShortName);
    }

    public List<Field> getField90K(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField90K(), sequenceShortName);
    }

    public List<Field> getField95Q(String sequenceShortName) {
        return filterFieldsBySequenceShortName(getField95Q(), sequenceShortName);
    }

}
