package net.uglobal.swiftvalidator.xml.beans;

public class MT538 extends MTMessage {

}
