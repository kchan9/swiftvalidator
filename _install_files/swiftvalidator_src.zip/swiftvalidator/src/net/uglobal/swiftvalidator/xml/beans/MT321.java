package net.uglobal.swiftvalidator.xml.beans;

public class MT321 extends MTMessage {

}
