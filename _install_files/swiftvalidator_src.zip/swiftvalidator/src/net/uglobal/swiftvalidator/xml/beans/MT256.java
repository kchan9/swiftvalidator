package net.uglobal.swiftvalidator.xml.beans;

public class MT256 extends MTMessage {

}
