package net.uglobal.swiftvalidator.xml.beans;

public class MT559 extends MTMessage {

}
