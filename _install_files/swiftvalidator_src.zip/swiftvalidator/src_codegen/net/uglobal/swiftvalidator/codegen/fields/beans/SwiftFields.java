package net.uglobal.swiftvalidator.codegen.fields.beans;

import java.util.List;

public class SwiftFields {
	private List<Field> fields;
}
