package net.uglobal.gui.swiftvalidator.syntheticdata;

import net.uglobal.gui.GenericTree;

public class SyntheticDataTree extends GenericTree {
	public SyntheticDataTree() {
		super("MT");
	}
}
