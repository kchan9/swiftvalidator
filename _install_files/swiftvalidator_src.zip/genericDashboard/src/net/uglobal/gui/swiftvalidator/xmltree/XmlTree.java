package net.uglobal.gui.swiftvalidator.xmltree;

public class XmlTree extends net.uglobal.gui.GenericTree {
	public XmlTree() {
		super("MT");
	}
}
