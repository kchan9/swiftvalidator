package net.uglobal.gui.swiftvalidator.xmltree;

import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

public class XmlTreeModel implements TreeModel {

	@Override
	public void addTreeModelListener(TreeModelListener treemodellistener) {
		// TODO Auto-generated method stub

	}

	@Override
	public Object getChild(Object obj, int i) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getChildCount(Object obj) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getIndexOfChild(Object obj, Object obj1) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getRoot() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isLeaf(Object obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void removeTreeModelListener(TreeModelListener treemodellistener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void valueForPathChanged(TreePath treepath, Object obj) {
		// TODO Auto-generated method stub

	}

}
